//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WorldCup.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_WORLDCTYPE                  129
#define IDD_ADD_TEAM                    130
#define IDD_ADD_PLAYER                  131
#define IDD_ADD_MATCH                   132
#define IDD_LOOK_TEAM                   134
#define IDD_LOOK_MATCH                  135
#define IDD_ADD_SCORE                   136
#define IDC_EDIT1                       1000
#define IDC_EDIT2                       1001
#define IDC_NUMBER                      1002
#define IDC_WEIGHT1                     1002
#define IDC_TIMING                      1002
#define IDC_RANKING                     1003
#define IDC_WEIGHT2                     1003
#define IDC_AGAINST                     1003
#define IDC_TEAM                        1004
#define IDC_NAME                        1005
#define IDC_POSITION                    1006
#define IDC_LOOK_TEAM                   1006
#define IDC_TEAM1                       1009
#define IDC_TEAM2                       1010
#define IDC_PLAYER                      1011
#define IDC_PLAYER2                     1012
#define ID_MENUTEAM                     32771
#define ID_MENUPLAYER                   32772
#define ID_MENUMATCH                    32773
#define ID_LOOK                         32774
#define ID_TEAMINFORMATION              32775
#define ID_MENUTEAMINFORMATION          32776
#define ID_MENULOOKMATCH                32777
#define ID_MENUSCORE                    32778

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32779
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
