# Final Project for Data Structure and Algorithm - A World Cup Simulator
## How the Project Is Going to Be?
The project will be a simulator of the FIFA World Cup where users input a time as the checkpoint, 
the system will return a "current" result of on-going or finished matches and prediction of the 
upcomming events, just as what you have seen during the world cup. The simulator will also provide 
current ranking of goals, penalties and so on.
## How the Project Is Composed?
The first part, which is packed in the Python folder, is used as internet crawler.  It crawls and 
parses html pages, then stores the crawled information in .json documents. The logic part, where algorithmetical 
realization of stacks, graphs, queues, and trees are implemented, is written in C++ language, which will be finished 
soon.

Good luck to me~
2018/OCT/15 23:28
