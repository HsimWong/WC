#include "Stack.h"
#include<iostream>
// #include "Match.h"
#include "functions.h"
#include <math.h>
using namespace std;



int main(){
	// Match * match = new Match(5);
	// cout << match -> get_match_id();
	string s = "-79812015279";
	long long a = str2int(s);
	cout << a;

	
}